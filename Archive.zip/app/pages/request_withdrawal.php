<?php
defined("BASEPATH") or die("ACCESS DENIED");
?>

<div class="my-3 my-md-5">
  <div class="container">
    <div class="page-header">
      <h1 class="page-title">
        Withdrawal Request
      </h1>

    </div>

    <!--<div class="card col-lg-6">
      <div class="card-header">
        <?php if(!empty($error)) { ?>
          <div class="alert alert-info"><?php echo $error; ?></div>
        <?php } ?>
      </div>-->
      <div class="my-3 my-md-5">
  <div class="container">
    <div class="page-header">
      <h1 class="page-title">
        Via Bank Transfer
      </h1>

    </div>

    <div class="card col-lg-6">
      <div class="card-header">
        <?php if(!empty($error)) { ?>
          <div class="alert alert-info"><?php echo $error; ?></div>
        <?php } ?>
      </div>
      <div class="card-body">
          <form action="<?php echo base_url('app/request_withdrawal') ?>" method="post">
            <div class="row">
              <div class="col-12">
                  <div class="form-group">
                      <label for="InputName">Full Name<span class="requred">*</span></label>
                      <input name="fullName" type="text" class="form-control" id="InputName" placeholder="Enter your full name" required>
                  </div>
                  <div class="form-group">
                      <label for="InputName">Bank Name<span class="requred">*</span></label>
                      <input name="bankName" type="text" class="form-control" id="InputName" placeholder="Enter your bank name" required>
                  </div>
                  <div class="form-group">
                      <label for="InputName">Account Number<span class="requred">*</span></label>
                      <input name="accountno" type="text" class="form-control" id="InputName" placeholder="Enter account number" required>
                  </div>
                  <div class="form-group">
                      <label for="InputName">Swift Code (optional)</label>
                      <input name="swiftCode" type="text" class="form-control" id="InputName" placeholder="Enter Swift Code" required>
                  </div>
                  <div class="form-group">
                      <label for="InputName">Amount<span class="requred">*</span></label>
                      <input name="amount" type="text" class="form-control" id="InputName" placeholder="Withdrawal Amount ($)" required>
                  </div>
                  
              </div>

              <div class="col-12">
                <button type="submit" class="btn btn-primary">Submit</button>
              </div>

            </div>
          </form>
      </div>
    </div>
  </div>
</div>

<div class="row">
  <div class="container">
    <div class="page-header">
      <h1 class="page-title">
        Via Bitcoin
      </h1>
    </div>

    <div class="card col-lg-6">
      <div class="card-header">
        <?php if(!empty($error)) { ?>
          <div class="alert alert-info"><?php echo $error; ?></div>
        <?php } ?>
      </div>
      <div class="card-body">
          <form action="<?php echo base_url('app/request_withdrawal') ?>" method="post">
            <div class="row">
              <div class="col-12">
                  <div class="form-group">
                      <label for="InputName">Bitcoin Wallet Address</label>
                      <input name="bitcoin_address" type="text" class="form-control" id="InputName" placeholder="Enter your bitcoin wallet address" required>
                  </div>
                  <div class="form-group">
                      <label for="InputName">Amount<span class="requred">*</span></label>
                      <input name="amount" type="text" class="form-control" id="InputName" placeholder="Withdrawal Amount ($)" required>
                  </div>
                  
              </div>

              <div class="col-12">
                <button type="submit" class="btn btn-primary">Submit</button>
              </div>

            </div>
          </form>
      </div>
    </div>
  </div>
</div>

<?php /*

<div class="contact">
  <div class="container">
    <div class="row justify-content-center">
      <div class="col-xl-6 col-lg-6">
        <div class="section-title text-center">
            <h2>Contact Us For <span>Support</span></h2>
            <p>Have questions? want to track your investment? we would love to hear from you.</p>
        </div>
      </div>
    </div>

      <div class="row">
          <div class="col-xl-12 col-lg-12">
              <form class="contact-form" method="post" action="<?php echo base_url('contact'); ?>">
                <div class="row">
                  <?php if(isset($error)) { ?>
                    <div class="col-xl-12 col-lg-12">
                      <div class="alert alert-<?php echo $error->status; ?>">
                        <?php echo $error->message; ?>
                      </div>
                    </div>
                  
                  <?php } ?>
                </div>
                <div class="row">
                    <div class="col-xl-6 col-lg-6">
                        <div class="form-group">
                            <label for="InputName">Name<span class="requred">*</span></label>
                            <input name="name" type="text" class="form-control" id="InputName" placeholder="Enter Your Name" required>
                        </div>
                    </div>
                    <div class="col-xl-6 col-lg-6">
                        <div class="form-group">
                            <label for="InputMail">E-mail<span class="requred">*</span></label>
                            <input name="email" type="email" class="form-control" id="InputMail" placeholder="Enter Your E-mail Address" required>
                        </div>
                    </div>
                    <div class="col-xl-6 col-lg-6">
                        <div class="form-group">
                            <label for="InputPhone">Phone<span class="requred">*</span></label>
                            <input name="phone" type="text" class="form-control" id="InputPhone" placeholder="Enter Your Phone Number" required>
                        </div>
                    </div>
                    <div class="col-xl-6 col-lg-6">
                        <div class="form-group">
                            <label for="InputSubject">Subject<span class="requred">*</span></label>
                            <input name="subject" type="text" class="form-control" id="InputSubject" placeholder="Enter Your Subject" required>
                        </div>
                    </div>
                    <div class="col-xl-12 col-lg-12">
                        <div class="form-group">
                            <label for="exampleFormControlTextarea1">Meassage<span class="requred">*</span></label>
                            <textarea name="message" class="form-control" id="exampleFormControlTextarea1" rows="3" placeholder="Enter Your Meassage" required=""></textarea>
                        </div>
                    </div>
                    <div class="col-xl-12 col-lg-12">
                        <button type="submit">Send Now</button>
                    </div>
                </div>
              </form>
          </div>
      </div>
  </div>
</div>

*/