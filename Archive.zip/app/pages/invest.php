<?php
defined("BASEPATH") or die("ACCESS DENIED");
?>

<div class="main-content">
    <section class="section">
      <div class="row">
        <div class="col-lg-6">
          <div class="card">
            <div class="card-header">
              <h4><?php echo $content["bitcoin_price_calculator"]?></h4>
            </div>
            <div class="card-body">
              <coin-ponent></coin-ponent>
            </div>
          </div>
        </div>

        <div class="col-lg-6">
          <form class="card" method="post" action="<?php echo base_url('app/invest');?>">
            <div class="card-header">
              <h4 class="card-title"><?php echo $content["please_fill_correctly"] ?></h4>
            </div>

            <div class="card-body">
              <div class="row">
                <div class="col-12">
                  <div class="form-group">
                    <?php if(isset($error)) { ?>
                      <div class="col-xl-12 col-lg-12">
                        <div class="alert alert-<?php echo $error->status; ?>">
                          <?php echo $error->message; ?>
                        </div>
                      </div>
                    <?php } ?>
                  </div>
                  <div class="form-group">
                    <label class="form-label"><?php //echo $settings->address ?></label>
                    <img style="height: 200px; width: 200px;" data-address="<?php echo $settings->address;?>" class="form-control bitcoin-address" src="https://chart.googleapis.com/chart?chs=250x250&cht=qr&chl=<?php echo $settings->address;?>">
                    <span><?php echo $content["tap_image_to_copy"]?> <?php echo $settings->address;?></span>
                    <!-- <span>click to copy</span> -->
                  </div>
                  <div class="form-group">
                    <label class="form-label"><?php echo $content["amount"]?></label>
                    <input type="text" name="amount" class="form-control" value="<?php echo set_value('amount')?>" required>
                    <span><?php echo $content["click_done"]?></span>
                    <input type="hidden" value="min_amount", name="min_amount">
                  </div>
                  
                  

                  <div class="form-group">
                      <button class="btn btn-info btn-small" type="submit"><?php echo $content["done"]; ?></button>
                      <!--<a class="btn btn-primary btn-small pull-right" href="https://payments.changelly.com"><?php echo $content["pay_with_card"]; ?></a>-->
                  </div>
                </div>
              </div>
            </div>
          </form>
        </div>

      </div>
    </section>
</div>
                </div>

                <!-- <div class="form-group">
                    <label class="form-label">Your Bitcoin Address</label>
                    <input name="address" class="form-control" type="text" value="<?php //echo $data->user->bitcoin_address == null ? set_value('address') : $data->user->bitcoin_address?>" required >
                </div> -->
              </div>
            </div>
          </div>
        </form>
      </div>
    </div>
  </div>
</div>

<script src="https://cdn.jsdelivr.net/gh/coinponent/coinponent@1.2.6/dist/coinponent.js"></script>
<script>
$(function(){
  $(".bitcoin-address").click(function(e) {
    e.preventDefault();
    let text = "<?php echo $settings->address;?>"
    copyToClipboard(text)
    alert("copied")
  })

  function copyToClipboard(text) {
    if (window.clipboardData && window.clipboardData.setData) {
        // Internet Explorer-specific code path to prevent textarea being shown while dialog is visible.
        return clipboardData.setData("Text", text);

    }
    else if (document.queryCommandSupported && document.queryCommandSupported("copy")) {
        var textarea = document.createElement("textarea");
        textarea.textContent = text;
        textarea.style.position = "fixed";  // Prevent scrolling to bottom of page in Microsoft Edge.
        document.body.appendChild(textarea);
        textarea.select();
        try {
            return document.execCommand("copy");  // Security exception may be thrown by some browsers.
        }
        catch (ex) {
            console.warn("Copy to clipboard failed.", ex);
            return false;
        }
        finally {
            document.body.removeChild(textarea);
        }
    }
}

})
</script>

