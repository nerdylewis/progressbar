<?php
defined("BASEPATH") or die("ACCESS DENIED");
?>

<div class="main-content">
  <section class="section">
    <div class="row">
      <div class="col-lg-12">
            <div class="card card-profile">
              <div class="card-header" style="background-image: url(demo/photos/eberhard-grossgasteiger-311213-500.jpg);"></div>
              <div class="card-body text-center">
                <img class="card-profile-img" src="demo/faces/male/16.jpg">
                <h3 class="mb-3"><?php echo ucwords($data->user->fullname) ?></h3>
                
                <!-- <button class="btn btn-outline-primary btn-sm">
                  <span class="fa fa-twitter"></span> Follow
                </button> -->
              </div>
            </div>
            
            <div class="card">
              <div class="card-header">
                <h3 class="card-title">Edit Profile</h3>
              </div>
              <div class="card-body">
                <form method="post" action="<?php echo base_url('app/profile');?>">
                  <div class="row">
                    <?php if(isset($error)) { ?>
                      <div class="col-xl-12 col-lg-12">
                        <div class="alert alert-<?php echo $error->status; ?>">
                          <?php echo $error->message; ?>
                        </div>
                      </div>
                    
                    <?php } ?>
                  </div>
                  <div class="row">
                    <div class="col-auto">
                      <span class="avatar avatar-xl" style="background-image: url(demo/faces/female/9.jpg)"></span>
                    </div>
                    <div class="col">
                      <div class="form-group">
                        <label class="form-label">Email Address</label>
                        <input name="email" class="form-control" value="<?php echo $data->user->email?>" readonly>
                        <span><?php echo $content["referal_link"];?> https://www.universalfxtrade/app/register/?ref=<?php echo $data->user->username ?></span>
                      </div>
                    </div>
                  </div>
                  <div class="form-group">
                    <label class="form-label">Full Name</label>
                    <input name="fullname" class="form-control" placeholder="Enter a new secret question" required value="<?php echo $data->user->fullname ?>">
                  </div>
                  <!--<div class="form-group">
                    <label class="form-label">Secret Question</label>
                    <input name="secret_question" class="form-control" placeholder="Enter a new secret question" required value="<?php echo $data->user->secret_question?>">
                  </div>
                  
                  <div class="form-group">
                    <label class="form-label">Secret Answer</label>
                    <input name="secret_answer" class="form-control" placeholder="Enter a new secret answer" value="<?php echo set_value('secret_answer')?>">
                  </div>-->

                  <div class="form-group">
                    <label class="form-label">Old Password</label>
                    <input type="password" name="oldpass" class="form-control" placeholder="Enter your current password">
                  </div>

                  <div class="form-group">
                    <label class="form-label">New Password</label>
                    <input name="newpass" type="password" class="form-control" value="" placeholder="Enter your new password">
                  </div>

                  <div class="form-group">
                    <label class="form-label">Confirm New Password</label>
                    <input type="password" name="confirmpass" class="form-control" placeholder="Repeat your new password">
                  </div>

                  <div class="form-group">
                    <label class="form-label">Wallet Address</label>
                    <input name="address" class="form-control" placeholder="new wallet">
                  </div>
                  <div class="form-footer">
                    <button class="btn btn-primary btn-block">Save</button>
                  </div>

                  
                </form>
              </div>
            </div>
          </div>
    </div>
  </section>
</div>
