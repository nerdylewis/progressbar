<?php
defined("BASEPATH") or die("ACCESS DENIED");
?>

<div class="page-title">
  <div class="container">
      <div class="row justify-content-center">
          <div class="col-xl-8 col-lg-8">
              <div class="page-title-content">
                  <h1>Contact Us</h1>
                  <!-- <p>Enjoy real benefits and rewards on your accrue investing.</!--> -->
              </div>
          </div>
      </div>
  </div>
</div>

<div class="contact">
  <div class="container">
    <div class="row justify-content-center">
      <div class="col-xl-6 col-lg-6">
        <div class="section-title text-center">
            <h2>Contact Us For <span>Support</span></h2>
            <p>Have questions? want to track your investment? we would love to hear from you.</p>
        </div>
      </div>
    </div>

      <div class="row">
          <div class="col-xl-12 col-lg-12">
              <form class="contact-form" method="post" action="<?php echo base_url('contact'); ?>">
                <div class="row">
                  <?php if(isset($error)) { ?>
                    <div class="col-xl-12 col-lg-12">
                      <div class="alert alert-<?php echo $error->status; ?>">
                        <?php echo $error->message; ?>
                      </div>
                    </div>
                  
                  <?php } ?>
                </div>
                <div class="row">
                    <div class="col-xl-6 col-lg-6">
                        <div class="form-group">
                            <label for="InputName">Name<span class="requred">*</span></label>
                            <input name="name" type="text" class="form-control" id="InputName" placeholder="Enter Your Name" required>
                        </div>
                    </div>
                    <div class="col-xl-6 col-lg-6">
                        <div class="form-group">
                            <label for="InputMail">E-mail<span class="requred">*</span></label>
                            <input name="email" type="email" class="form-control" id="InputMail" placeholder="Enter Your E-mail Address" required>
                        </div>
                    </div>
                    <div class="col-xl-6 col-lg-6">
                        <div class="form-group">
                            <label for="InputPhone">Phone<span class="requred">*</span></label>
                            <input name="phone" type="text" class="form-control" id="InputPhone" placeholder="Enter Your Phone Number" required>
                        </div>
                    </div>
                    <div class="col-xl-6 col-lg-6">
                        <div class="form-group">
                            <label for="InputSubject">Subject<span class="requred">*</span></label>
                            <input name="subject" type="text" class="form-control" id="InputSubject" placeholder="Enter Your Subject" required>
                        </div>
                    </div>
                    <div class="col-xl-12 col-lg-12">
                        <div class="form-group">
                            <label for="exampleFormControlTextarea1">Meassage<span class="requred">*</span></label>
                            <textarea name="message" class="form-control" id="exampleFormControlTextarea1" rows="3" placeholder="Enter Your Meassage" required=""></textarea>
                        </div>
                    </div>
                    <div class="col-xl-12 col-lg-12">
                        <button type="submit">Send Now</button>
                    </div>
                </div>
              </form>
          </div>
      </div>
  </div>
</div>