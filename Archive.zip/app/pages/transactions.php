<?php
defined("BASEPATH") or die("ACCESS DENIED");
?>


<div class="main-content">
    <section class="section">
      <div class="row">
        <div class="col-md-12">
          <div class="card">
            <div class="card-header">
              <h4><?php echo $content["transactions"]?></h4>
              <div class="card-header-action">
                <!-- <a href="#" class="btn btn-danger">View More <i class="fas fa-chevron-right"></i></a> -->
              </div>
            </div>

            <div class="card-body p-0">
                  <div class="table-responsive table-invoice">
                    <table class="table table-striped">
                      <tr>
                        <!-- <th></th>
                        <th></th> -->
                        <th><?php echo $content["date"]?></th>
                        <th><?php echo $content["amount"]?></th>
                        <th><?php echo $content["status"]?></th>
                      </tr>
                      <?php
                        $transactions = $data->transactions;
                        if(!empty($transactions)){
                          $count = 1;
                          foreach($transactions as $row){
                            $status = "";
                            $text = "";
                            switch($row->status) {
                              case 0:
                                $status = "badge-warning";
                                $text = $content["pending"];
                              break;
                              case 1:
                                $status = "btn-primary";
                                $text = $content["success"];
                              break;
                              case 2:
                                $status = "badge-danger";
                                $text = $content["status"];
                              break;
                            }
                      ?>
                      <tr>
                        <!-- <td><a href="#">INV-87239</a></td>
                        <td class="font-weight-600">Kusnadi</td> -->
                        <td><?php echo date('F j, Y \a\t H:s a', $row->date); ?></td>
                        <td>
                          $<?php echo number_format($row->amount, 2); ?>
                        </td>
                        <td><div class="badge <?php echo $status; ?>"><?php echo $text; ?></div></td>
                      </tr>
                      <?php }
                      
                          } else {?>
                        <tr>
                          <th><?php echo $content["no_transactions"]?></th>
                        </tr>
                          <?php } ?>
                    </table>
                  </div>
                </div>


        </div>
      </div>

    </section>
</div>