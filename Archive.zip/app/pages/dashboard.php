
<?php
defined("BASEPATH") or die("ACCESS DENIED");
$pending_withrawal = $user->parse('pending_withdrawals', 'count', $this->session->user_id);
?>

<!-- Main Content -->
      <div class="main-content">
        <section class="section">
          <div class="row">
            <div class="col-lg-4 col-md-4 col-sm-12">
              <div class="card card-statistic-2">
                <div class="card-stats">
                  <div class="card-stats-title"><?php echo $content["account_statistics"] ?>
                    <!-- <div class="dropdown d-inline">
                      <a class="font-weight-600 dropdown-toggle" data-toggle="dropdown" href="#" id="orders-month">August</a>
                      <ul class="dropdown-menu dropdown-menu-sm">
                        <li class="dropdown-title">Select Month</li>
                        <li><a href="#" class="dropdown-item">January</a></li>
                        <li><a href="#" class="dropdown-item">February</a></li>
                        <li><a href="#" class="dropdown-item">March</a></li>
                        <li><a href="#" class="dropdown-item">April</a></li>
                        <li><a href="#" class="dropdown-item">May</a></li>
                        <li><a href="#" class="dropdown-item">June</a></li>
                        <li><a href="#" class="dropdown-item">July</a></li>
                        <li><a href="#" class="dropdown-item active">August</a></li>
                        <li><a href="#" class="dropdown-item">September</a></li>
                        <li><a href="#" class="dropdown-item">October</a></li>
                        <li><a href="#" class="dropdown-item">November</a></li>
                        <li><a href="#" class="dropdown-item">December</a></li>
                      </ul>
                    </div> -->
                  </div>
                  <div class="card-stats-items">
                    <?php 
                    $pending = $user->parse('pending_deposits', $data->user->id);
                    $pending = !empty($pending) ? count($pending) : 0;

                    $completed = $user->parse('confirmed_deposits', $data->user->id);
                    $completed = !empty($completed) ? count($completed) : 0;

                    $active = $user->parse('pending_withdrawals', $data->user->id);
                    $active = !empty($active) ? count($active) : 0;

                    $all = $user->parse('total_transactions', $data->user->id);

                    ?>
                    <div class="card-stats-item">
                      <div class="card-stats-item-count"><?php echo $pending; ?></div>
                      <div class="card-stats-item-label"><?php echo $content["pending"] ?></div>
                    </div>
                    <div class="card-stats-item">
                      <div class="card-stats-item-count"><?php echo $active ?></div>
                      <div class="card-stats-item-label"><?php echo $content["active"]?></div>
                    </div>
                    <div class="card-stats-item">
                      <div class="card-stats-item-count"><?php echo $completed; ?></div>
                      <div class="card-stats-item-label"><?php echo $content["completed"] ?></div>
                    </div>
                  </div>
                </div>
                <div class="card-icon shadow-primary bg-primary">
                  <i class="fas fa-archive"></i>
                </div>
                <div class="card-wrap">
                  <div class="card-header">
                    <h4><?php echo $content["total_transactions"] ?></h4>
                  </div>
                  <div class="card-body">
                    <?php echo $all;?>
                  </div>
                </div>
              </div>
            </div>
            <div class="col-lg-4 col-md-4 col-sm-12">
              <div class="card card-statistic-2">
                <div class="card-chart">
                  <canvas id="balance-chart" height="80"></canvas>
                </div>
                <div class="card-icon shadow-primary bg-primary">
                  <i class="fas fa-dollar-sign"></i>
                </div>
                <div class="card-wrap">
                  <div class="card-header">
                    <h4><?php echo $content["balance"] ?></h4>
                  </div>
                  <div class="card-body">
                    $<?php echo number_format($data->user->balance, 2); ?>
                  </div>
                </div>
              </div>
            </div>
            <div class="col-lg-4 col-md-4 col-sm-12">
              <div class="card card-statistic-2">
                <div class="card-chart">
                  <canvas id="sales-chart" height="80"></canvas>
                </div>
                <div class="card-icon shadow-primary bg-primary">
                  <i class="fas fa-shopping-bag"></i>
                </div>
                <div class="card-wrap">
                  <div class="card-header">
                    <h4><?php echo $content["active_trading"] ?></h4>
                  </div>
                  <div class="card-body">
                    $<?php //echo $this->core->trading_balance($data->user->id); ?>
                    <?php echo number_format($data->user->trading_balance, 2); ?>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div class="mt-4 mb-4 p-3 hide-sidebar-mini align-right">
            <a href="<?php echo base_url(); ?>app/invest" class="btn btn-primary btn-lg btn-block btn-icon-split">
              <i class="fas fa-plus"></i> <?php echo $content["deposit"];?>
            </a>
          </div>
          <!--<a href="<?php echo base_url(); ?>app/invest" class="nav-link"><i class="fas fa-sign-in-alt"></i><span><?php //echo $content["deposit"];?></span></a>-->
          <div class="mt-4 mb-4 p-3 hide-sidebar-mini align-right">
            <a href="<?php echo base_url(); ?>app/request_withdrawal" class="btn btn-primary btn-lg btn-block btn-icon-split">
              <i class="fas fa-rocket"></i> <?php echo $content["withdraw"];?>
            </a>
          </div>
          <div class="row">
            <div class="col-lg-6 col-md-6">
              <div class="card">
                <div class="card-header">
                  <h4><?php echo $content["bitcoin_trading_chart"] ?></h4>
                </div>
                <div class="card-body">
                  <!-- <canvas id="myChart" height="158"></canvas> -->
                  <div id="chart-donut" style="height: 22rem; background-color: #1D2330; overflow:hidden; box-sizing: border-box; border: 1px solid #282E3B; border-radius: 4px; text-align: right; line-height:14px; font-size: 12px; font-feature-settings: normal; text-size-adjust: 100%; box-shadow: inset 0 -20px 0 0 #262B38;padding:1px;padding: 0px; margin: 0px; width: 100%;">
                    <div style="height: 21rem; padding:0px; margin:0px; width: 100%;">
                      <iframe src="https://widget.coinlib.io/widget?type=chart&theme=dark&coin_id=859&pref_coin_id=1505" width="100%" height="100%" scrolling="auto" marginwidth="0" marginheight="0" frameborder="0" border="0" style="border:0;margin:0;padding:0;line-height:14px;"></iframe>
                    </div>
                  </div>
                </div>
              </div>
            </div>

            <div class="col-md-6 col-lg-6">
              <div class="card">
                <div class="card-header">
                  <h4><?php echo $content["ether_trading_chart"]?></h4>
                </div>
                <div class="card-body">
                  <div id="chart-donut" style="height: 22rem; background-color: #1D2330; overflow:hidden; box-sizing: border-box; border: 1px solid #282E3B; border-radius: 4px; text-align: right; line-height:14px; font-size: 12px; font-feature-settings: normal; text-size-adjust: 100%; box-shadow: inset 0 -20px 0 0 #262B38;padding:1px;padding: 0px; margin: 0px; width: 100%;">
                    <div style="height:20rem; padding:0px; margin:0px; width: 100%;">
                      <iframe src="https://widget.coinlib.io/widget?type=chart&theme=dark&coin_id=145&pref_coin_id=1505" width="100%" height="100%" scrolling="auto" marginwidth="0" marginheight="0" frameborder="0" border="0" style="border:0;margin:0;padding:0;line-height:14px;"></iframe>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div class="row">
            
            <div class="col-md-12">
              <div class="card">
                <div class="card-header">
                  <h4><?php echo $content["other_trading_chart"]?></h4>
                </div>
                <div class="card-body">
                  <div style="height:433px; background-color: #1D2330; overflow:hidden; box-sizing: border-box; border: 1px solid #282E3B; border-radius: 4px; text-align: right; line-height:14px; font-size: 12px; font-feature-settings: normal; text-size-adjust: 100%; box-shadow: inset 0 -20px 0 0 #262B38; padding: 0px; margin: 0px; width: 100%;">
                    <div style="height:413px; padding:0px; margin:0px; width: 100%;">
                      <iframe src="https://widget.coinlib.io/widget?type=full_v2&theme=dark&cnt=6&pref_coin_id=1505&graph=yes" width="100%" height="409px" scrolling="auto" marginwidth="0" marginheight="0" frameborder="0" border="0" style="border:0;margin:0;padding:0;"></iframe>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div class="row">
            <div class="col-md-12">
              <div class="card">
                <div class="card-header">
                  <h4>Transactions</h4>
                  <div class="card-header-action">
                    <a href="<?php echo base_url('app/transactions'); ?>" class="btn btn-danger"><?php echo $content["view_more"]?> <i class="fas fa-chevron-right"></i></a>
                  </div>
                </div>
                <div class="card-body p-0">
                  <div class="table-responsive table-invoice">
                    <table class="table table-striped">
                      <tr>
                        <!-- <th></th>
                        <th></th> -->
                        <th><?php echo $content["date"] ?></th>
                        <th><?php echo $content["amount"] ?></th>
                        <th><?php echo $content["status"] ?></th>
                      </tr>
                      <?php
                        $transactions = $data->transactions;
                        if(!empty($transactions)){
                          $count = 1;
                          foreach($transactions as $row){
                            $status = "";
                            $text = "";
                            switch($row->status) {
                              case 0:
                                $status = "badge-warning";
                                $text = $content["pending"];
                              break;
                              case 1:
                                $status = "btn-primary";
                                $text = $content["success"];
                              break;
                              case 2:
                                $status = "badge-danger";
                                $text = $content["cancelled"];
                              break;
                            }
                      ?>
                      <tr>
                        <!-- <td><a href="#">INV-87239</a></td>
                        <td class="font-weight-600">Kusnadi</td> -->
                        <td><?php echo date('F j, Y \a\t H:s a', $row->date); ?></td>
                        <td>
                          $<?php echo number_format($row->amount, 2); ?>
                        </td>
                        <td><div class="badge <?php echo $status; ?>"><?php echo $text; ?></div></td>
                      </tr>
                      <?php }
                      
                          }?>
                    </table>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </section>
      </div>