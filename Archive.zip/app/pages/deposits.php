<?php
defined("BASEPATH") or die("ACCESS DENIED");

$filter = $this->input->get('filter') ?? 'all';

$transactions = $this->ai->get_transactions($filter, null);
// $transactions = $data->transactions;


?>

<div class="my-3 my-md-5">
  <div class="container">
    <div class="page-header">
      <h1 class="page-title">
        Transactions
      </h1>
      <button class="btn btn-small btn-primary ml-auto" data-toggle="modal" data-target="#myModal">Add Transaction</button>
      
    </div>

    <div class="card">
      <div class="card-header">
          <?php echo ucwords($filter) ?> Transactions
      </div>
      
      <table class="table table-responsive card-table">
        <tbody>
          <tr>
            <th></th>
            <th></th>
            <th>Username</th>
            <th>Amount</th>
            <th>Date</th>
            <th>Plan</th>
            <th>Type</th>
            <th>Status</th>
            <th>Confirm</th> -->
          </tr>
          <?php
            if(!empty($transactions)){
              foreach($transactions as $row){
                $current = $user->get_user($row->user);
          ?>
          <tr>
            <th><?php echo $row->id;?></th>
            <th><img src="<?php echo base_url('theme/app/assets/images/crypto-currencies/bitcoin.svg')?>" alt="Bitcoin" class="w-4 h-4"></th>
            <th><?php echo $current->username; ?></th>
            <th><?php echo $row->amount ?></th>
            <th><?php echo $row->date?></th>
            <th><?php echo $row->plan ?></th>
            <th><?php echo $row->type == "debit" ? "Credit" : "Debit"?></th>
            <th><?php echo $row->confirmed == 1 ? '<span class="status-icon bg-success"></span> Confirmed' : '<span class="status-icon bg-danger"></span> Unconfirmed' ?></th>
            <th>
                <?php echo $row->confirmed == 1 ? '' : '<button data-deposit="'.$row->id.'"class="btn btn-primary">Confirm</button>' ?>
            </th>
              
          </tr>
          <?php
              }
            } else {
          ?>

            <tr>
              <th col="8">No transactions yet</th>
            </tr>
          <?php
            }
          ?>
        </tbody>
      </table>
    </div>
  </div>
</div>

<!-- Modal -->
<div id="myModal" class="modal fade" role="dialog">
  <div class="modal-dialog">
    <div class="card">
      <div class="card-header">
          Add Transaction
      </div>
      <div class="card-body">
        <form action="#" method="post">
          <div class="row">
            <div class="form-group">
              <label class="form-label">Choose Plan</label>
              <select class="form-control" name="plan">
                <?php foreach($plans as $plan){ ?>
                <option value="<?php echo $plan->value?>"><?php echo $plan->name." (".$plan->value."%)" ?></option>

                <?php } ?>
              </select>
            </div>
          </div>
        </form>
        
      </div>
    </div>
    <!-- Modal content-->
    <!-- <div class="modal-content">

      <div class="modal-header">
        <h4 class="modal-title">New Transaction</h4>
        <button type="button" class="close mr-auto" data-dismiss="modal"></button>
        
      </div>
      <div class="modal-body">
        <p>Some text in the modal.</p>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
      </div>
    </div> -->

  </div>
</div>