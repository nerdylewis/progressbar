<?php
defined("BASEPATH") or die("ACCESS DENIED");
?>

<div class="my-3 my-md-5">
  <div class="container">
    <div class="page-header">
      <h1 class="page-title">
        Via Bank Transfer
      </h1>

    </div>

    <div class="card col-lg-6">
      <div class="card-header">
        <?php if(!empty($error)) { ?>
          <div class="alert alert-info"><?php echo $error; ?></div>
        <?php } ?>
      </div>
      <div class="card-body">
          <form action="<?php echo base_url('app/request_withdrawal') ?>" method="post">
            <div class="row">
              <div class="col-12">
                  <div class="form-group">
                      <label for="InputName">Full Name<span class="requred">*</span></label>
                      <input name="fullName" type="text" class="form-control" id="InputName" placeholder="Enter your full name" required>
                  </div>
                  <div class="form-group">
                      <label for="InputName">Bank Name<span class="requred">*</span></label>
                      <input name="bankName" type="text" class="form-control" id="InputName" placeholder="Enter your bank name" required>
                  </div>
                  <div class="form-group">
                      <label for="InputName">Account Number<span class="requred">*</span></label>
                      <input name="accountno" type="text" class="form-control" id="InputName" placeholder="Enter account number" required>
                  </div>
                  <div class="form-group">
                      <label for="InputName">Swift Code (optional)</label>
                      <input name="swiftCode" type="text" class="form-control" id="InputName" placeholder="Enter Swift Code" required>
                  </div>
                  <div class="form-group">
                      <label for="InputName">Amount<span class="requred">*</span></label>
                      <input name="amount" type="text" class="form-control" id="InputName" placeholder="Withdrawal Amount ($)" required>
                  </div>
                  
              </div>

              <div class="col-12">
                <button type="submit" class="btn btn-primary">Submit</button>
              </div>

            </div>
          </form>
      </div>
    </div>
  </div>
</div>