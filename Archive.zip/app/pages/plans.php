<?php
defined("BASEPATH") or die("ACCESS DENIED");
?>
<div class="page-title">
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-xl-8 col-lg-8">
                <div class="page-title-content">
                    <h1>Investment Plans</h1>
                    <p>Enjoy real benefits and rewards on your investing.</p>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="transaction">
    <div class="container">
      <div class="row justify-content-center">
          <div class="col-xl-8 col-lg-8">
              <div class="section-title text-center">
                  <!-- <h2>Latest<span> Transaction</span></h2> -->
                  <p>
We offer you the fastest and the most legit way to successfully accumulate your BTC by getting you profit daily and hourly.</p>
<p>Below are some of the features that put us above other bitcoin investment platforms.</p>
              </div>
          </div>
      </div>
                  
    </div>
</div>

<div class="pricing">
  <div class="bg-img">
      <img src="<?php echo base_url('theme/lite/assets/img/info-feature-bg.png');?>" alt="">
  </div>
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-xl-8 col-lg-8">
                <div class="section-title text-center">
                    <h2>Grab Our<span> Mega Package</span></h2>
                    <p>Put your investing ideas into action with full range of investments.
                        Enjoy real benefits and rewards on your accrued investing.</p>
                </div>
            </div>
        </div>

        <div class="row">
            <div class="col-xl-4 col-lg-4 col-md-6">
                <div class="single-plan">
                    <h3>Basic Plan</h3>
                    <h4>Features</h4>
                    <ul>
                        <li>Minimum Deposit $10</li>
                        <li>Maximum Deposit $1,000</li>
                        <li>Enhanced security</li>
                        <li>Access to all features</li>
                        <li>24/7Support</li>
                    </ul>
                    <h5><span class="price">127%</span><br>
                    <span class="time">/ Month</span></h5>
                    <a class="start-button" href="<?php echo base_url('launch')?>">Start Now</a>
                </div>
            </div>

            <div class="col-xl-4 col-lg-4 col-md-6">
                <div class="feature-bar">
                    <h4>Most Popular</h4>
                </div>
                <div class="single-plan popular">
                    <h3>Gold Plan</h3>
                    <h4>Features</h4>
                    <ul>
                        <li>Minimum Deposit $100</li>
                        <li>Miximum Deposit $5,000</li>
                        <li>Enhanced security</li>
                        <li>Access to all features</li>
                        <li>24/7Support</li>
                    </ul>
                    <h5><span class="price">150%</span><br>
                        <span class="time">/ Month</span></h5>
                    <a class="start-button" href="<?php echo base_url('launch')?>">Start Now</a>
                </div>
            </div>

            <div class="col-xl-4 col-lg-4 col-md-6">
                <div class="single-plan">
                    <h3>Platinum Plan</h3>
                    <h4>Features</h4>
                    <ul>
                        <li>Minimum Deposit $10,000</li>
                        <li>Miximum Deposit $100,000</li>
                        <li>Enhanced security</li>
                        <li>Access to all features</li>
                        <li>24/7Support</li>
                    </ul>
                    <h5><span class="price">160%</span><br>
                        <span class="time">/ 3 weeks</span></h5>
                    <a class="start-button" href="<?php echo base_url('launch')?>">Start Now</a>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="payment">
    <div class="container">
          <div class="row d-flex">
              <div class="col-xl-6 col-lg-6 col-md-6 d-flex align-items-center">
                <div class="row justify-content-center">
                    <div class="col-xl-12 col-lg-12">
                        <div class="section-title">
                            <h2>Accepted<br><span>Payment Method</span></h2>
                            <p>We accept Bitcoin!</p>
                        </div>
                    </div>

                    <div class="col-xl-12 col-lg-12">
                        <div class="part-accept">
                            <div class="single-accept">
                              <!-- <i class="flaticon-bitcoin"></i> -->
                                <img src="<?php echo base_url('theme/lite/assets/img/BTC.png');?>" alt="">
                            </div>
                            <!-- <div class="single-accept">
                                <img src="assets/img/accept-card-2.jpg" alt="">
                            </div>
                            <div class="single-accept">
                                <img src="assets/img/accept-card-3.jpg" alt="">
                            </div>
                            <div class="single-accept">
                                <img src="assets/img/accept-card-4.jpg" alt="">
                            </div> -->
                        </div>
                        <!-- <div class="part-accept">
                            <div class="single-accept">
                                <img src="assets/img/accept-card-5.jpg" alt="">
                            </div>
                            <div class="single-accept">
                                <img src="assets/img/accept-card-6.jpg" alt="">
                            </div>
                            <div class="single-accept">
                                <img src="assets/img/accept-card-7.jpg" alt="">
                            </div>
                        </div> -->
                    </div>
                  </div>
              </div>

              <!-- <div class="col-xl-6 co-lg-6 col-md-6">
                  <div class="part-form">
                      <h3>Calculate Your Profit</h3>
                      <form class="payment-form">
                        <div class="form-group">
                            <label for="InputAmount">Enter Ammount :</label>
                            <input type="text" class="form-control" id="InputAmount" placeholder="10">
                        </div>
                        <div class="form-group">
                            <label for="InputTprofit">Total Profit :</label>
                            <input type="text" class="form-control" id="InputTprofit" placeholder="$15">
                        </div>
                        <div class="form-group">
                            <label for="InputProfit">Net Profit :</label>
                            <input type="text" class="form-control" id="InputProfit" placeholder="$05">
                        </div>
                        <button type="submit">Continue</button>
                      </form>
                  </div>
              </div> -->
          </div>
    </div>
</div>