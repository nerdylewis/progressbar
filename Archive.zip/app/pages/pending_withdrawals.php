<?php
defined("BASEPATH") or die("ACCESS DENIED");
$filter = $this->input->get('filter') ?? 'all';
$requests = $user->get_requests($filter, $this->session->user_id);

// $transactions = $data->transactions;


?>

<div class="my-3 my-md-5">
  <div class="container">
    <div class="page-header">
      <h1 class="page-title">
        Withdrawal Requests
      </h1>


      <a href="<?php echo base_url('app/request_withdrawal')?>" class="btn btn-primary ml-auto">New Request</a>
      
    </div>

    <div class="card">
      <div class="card-header">
          <?php echo ucwords($filter) ?> Requests
      </div>
      <div class="table-responsive">      
        <table class="table card-table">
          <tbody>
            <tr>
              <th></th>
              <th></th>
              <th>Amount</th>
              <th>Status</th>
              <!-- <th>CMGR/Month</th>
              <th>Inflation</th> -->
            </tr>
            <?php
              if(!empty($requests)){
                $count = 1;
                foreach($requests as $row){
                  $current = $user->get_user($row->user);
            ?>
            <tr>
              <th><?php echo $count;?></th>
              <th><img src="<?php echo base_url('theme/app/assets/images/crypto-currencies/bitcoin.svg')?>" alt="Bitcoin" class="w-4 h-4"></th>
              <th><?php echo number_format($row->amount, 2)?></th>
              <th><?php echo $row->status == 1 ? '<span class="status-icon bg-success"></span>Payout Complete' : '<span class="status-icon bg-danger"></span>Unapproved' ?></th>
            </tr>
            <?php
            $count++;
                }
              } else {
            ?>

              <tr>
                <th col="8">No transactions yet</th>
              </tr>
            <?php
              }
            ?>
          </tbody>
        </table>
      </div>
    </div>
  </div>
</div>

<!-- Modal -->
<div id="myModal" class="modal fade" role="dialog">
  <div class="modal-dialog">
    <div class="card">
      <div class="card-header">
          Add Transaction
      </div>
      <div class="card-body">
        <form action="#" method="post">
          <div class="row">
            <div class="form-group">
              <label class="form-label">Choose Plan</label>
              <select class="form-control" name="plan">
                <?php foreach($plans as $plan){ ?>
                <option value="<?php echo $plan->value?>"><?php echo $plan->name." (".$plan->value."%)" ?></option>

                <?php } ?>
              </select>
            </div>
          </div>
        </form>
        
      </div>
    </div>
    <!-- Modal content-->
    <!-- <div class="modal-content">

      <div class="modal-header">
        <h4 class="modal-title">New Transaction</h4>
        <button type="button" class="close mr-auto" data-dismiss="modal"></button>
        
      </div>
      <div class="modal-body">
        <p>Some text in the modal.</p>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
      </div>
    </div> -->

  </div>
</div>