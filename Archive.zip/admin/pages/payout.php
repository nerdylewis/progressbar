<?php
defined("BASEPATH") or die("ACCESS DENIED");
if(isset($_GET['user'])) {
  $profile = $user->get_user($_GET['user']);
}
if(isset($_GET['amount'])) {
  $amount = $_GET['amount'];
}
?>

<div class="my-3 my-md-5">
  <div class="container">
    <div class="row">
      <div class="col-lg-6">
        <div class="card">
          <div class="card-header">
            <h3 class="card-title">Make Payment to user</h3>
          </div>
          <div class="card-body">
            <article class="media">
              <div class="mr-3">
                <div class="avatar avatar-xl" style="background-image: url(<?php echo base_url('theme/app/assets/images/crypto-currencies/bitcoin.svg')?>)"></div>
              </div>
              <div class="media-body">
                <div class="content" id="amountbox">

                  <div class="form-group">
                    <label class="form-label">User Address</label>
                    <input type="text" name="amount" class="form-control" readonly value="<?php echo isset($profile) ? $profile->bitcoin_wallet_address : 'this user has not invested'?>">
                  </div>

                  <div class="form-group">
                    <button id="continue" class="btn btn-small btn-primary">Copy</button>
                  </div>
                </div>
                <div class="content" id="addressBox" style="display: none;">

                  <figure>
                    
                  </figure>
                </div>
                <!-- <nav class="d-flex text-muted">
                  <a href="#" class="icon mr-3">
                    <i class="fe fe-repeat"></i>
                  </a>
                  <a href="#" class="icon mr-3">
                    <i class="fe fe-twitter"></i> 24
                  </a>
                  <a href="#" class="icon mr-3">
                    <i class="fe fe-heart"></i> 43
                  </a>
                  <a href="" class="text-muted ml-auto">
                    5 notes
                  </a>
                </nav> -->
              </div>
            </article>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>
<?php
if(isset($profile)){
  $settings = $user->get_settings();
?>
<script type="text/javascript">
$(function(){
  $("#continue").click(function(e){
    e.preventDefault()

    $('input[name=amount]').select()
    // $('input[name=amount]').setSelectionRange(0, 99999)
    document.execCommand("copy");
    alert("copied"); 
    // amount = $('input[name=amount]').val()
    // if(amount == ''){
    //   alert('enter amount');
    //   return false
    // }
    // $(this).attr('disabled', true);
    // url = encodeURI("https://chart.googleapis.com/chart?chs=300x300&cht=qr&chl="+message+amount)

    // $.get(url, function(data, status){

    //   if(status == 'success') {
    //     $('figure').html('<img width="300" height="300" alt="star" src="'+data+'">')
    //     $(this).attr('disabled', false);
    //   }
    // });
  })
})
</script>
<?php
}
?>