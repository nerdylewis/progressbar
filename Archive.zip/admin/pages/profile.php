<?php
defined("BASEPATH") or die("ACCESS DENIED");
?>

<div class="my-3 my-md-5">
  <div class="container">
    <div class="row">
      <div class="col-lg-4">
                <div class="card">
                  <div class="card-header">
                    <h3 class="card-title">Change Password</h3>
                  </div>
                  <div class="card-body">
                    <form method="post" action="<?php echo base_url('admin/profile');?>">
                      <div class="row">
                        <?php if(isset($error)) { ?>
                          <div class="col-xl-12 col-lg-12">
                            <div class="alert alert-<?php echo $error->status; ?>">
                              <?php echo $error->message; ?>
                            </div>
                          </div>
                        
                        <?php } ?>
                      </div>
                      
                      <div class="form-group">
                        <label class="form-label">Old Password</label>
                        <input type="password" name="oldpass" class="form-control" placeholder="Enter your current password" required>
                      </div>

                      <div class="form-group">
                        <label class="form-label">New Password</label>
                        <input name="newpass" type="password" class="form-control" value="" placeholder="Enter your new password" required>
                      </div>

                      <div class="form-group">
                        <label class="form-label">Confirm New Password</label>
                        <input type="password" name="confirmpass" class="form-control" placeholder="Repeat your new password" required>
                      </div>  

                      <div class="form-footer">
                        <button type="submit" class="btn btn-primary btn-block">Save</button>
                      </div>                    
                    </form>
                  </div>
                </div>
              </div>
    </div>
  </div>
</div>
