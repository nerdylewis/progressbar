<?php
defined("BASEPATH") or die("ACCESS DENIED");
$deposits = $admin->get_transactions("deposits", "all", null);
$withdrawals = $admin->get_transactions("withdrawals", "all", null);
$pending_deposits = $admin->get_transactions("deposits", "pending", null);
$pending_withdrawals = $admin->get_transactions("withdrawals", "pending", null);
$confirmed_deposits = $admin->get_transactions("deposits", "confirmed", null);
?>

<div class="my-3 my-md-5">
  <div class="container">
    <div class="page-header">
      <h1 class="page-title">
        Dashboard
      </h1>
    </div>

    <div class="row row-cards">
      <div class="col-6 col-sm-4 col-lg-2">
        <div class="card clickable" data-link="<?php echo base_url('admin/users')?>">
          <div class="card-body p-3 text-center">
            <!-- <div class="text-right text-green">
              6%
              <i class="fe fe-chevron-up"></i>
            </div> -->
            <div class="h1 m-0"><?php echo count($data->users)?></div>
            <div class="text-muted mb-4">Total Users</div>
          </div>
        </div>
      </div>

      <div class="col-6 col-sm-4 col-lg-2">
        <div class="card clickable" data-link="<?php echo base_url('vault/deposits')?>">
          <div class="card-body p-3 text-center">
            <div class="h1 m-0">
              <?php 
              echo count($deposits);
              ?></div>
            <div class="text-muted mb-4">Total Deposits</div>
          </div>
        </div>
      </div>

      <div class="col-6 col-sm-4 col-lg-2">
        <div class="card clickable" data-link="<?php echo base_url('vault/withdrawals')?>">
          <div class="card-body p-3 text-center">
            <div class="h1 m-0">
              <?php 
                echo count($withdrawals);
              ?>
              </div>
            <div class="text-muted mb-4">Total Withdrawals</div>
          </div>
        </div>
      </div>

      <div class="col-6 col-sm-4 col-lg-2">
        <div class="card clickable" data-link="<?php echo base_url('vault/deposits/?filter=pending')?>">
        
          <div class="card-body p-3 text-center">
            <div class="h1 m-0">
              <?php 
                echo count($pending_deposits);
                ?></div>
            <div class="text-muted mb-4">Total Pending Deposits</div>
          </div>
        </div>
      </div>
      

      <div class="col-6 col-sm-4 col-lg-2">
        <div class="card clickable" data-link="<?php echo base_url('vault/deposits/?filter=confirmed') ?>">
          <div class="card-body p-3 text-center">
            <div class="h1 m-0">
              <?php 
              echo count($confirmed_deposits)
                
            ?></div>
            <div class="text-muted mb-4">Total Confirmed Deposits</div>
          </div>
        </div>
      </div>
      
      <div class="col-6 col-sm-4 col-lg-2">
        <div class="card clickable" data-link="<?php echo base_url('vault/withdrawals/?filter=pending')?>">
          <div class="card-body p-3 text-center">
            <div class="h1 m-0">
              <?php 
              echo count($pending_withdrawals);
              ?></div>
            <div class="text-muted mb-4">Pending Withdrawals</div>
          </div>
        </div>
      </div>
    </div>
    
  </div>
</div>

<script>
$(function(){
  $('.clickable').click(function(e){
    e.preventDefault();
    var link = $(this).data('link');
    window.location.href = link
  })
})
</script>