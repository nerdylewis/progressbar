<?php
defined("BASEPATH") or die("ACCESS DENIED");
// use Carbon\Carbon;
?>


<div class="my-3 my-md-5">
    <div class="container">
        <div class="page-header d-print-name">
            <div class="row align-items-center">
                <div class="col">
                    <h1 class="page-title">
                        Create Message
                    </h1>
                </div>
            </div>
        </div>

        <div class="page-content">
            <div class="card">
                <!-- <div class="row"> -->
                    <!-- <div class="container"> -->
                <div class="col col-12 mt-3">
                    <?php
                        if(isset($errors) && $errors != null) {
                    
                    ?>
                    <div class="alert alert-info">
                        <?php echo $errors; ?>
                    </div>
                    <?php } ?>
                </div>

                <div class="col col-lg-7 col-md-7 mt-3">
                    <form action="" method="POST">
                        <div class="form-group">
                            <div class="mb-3 mt-4">
                                <label class="form-label">Recipient Username</label>
                                <input value="<?php echo set_value('to_user') ?>" name="to_user" class="form-control" list="datalistOptions" placeholder="Type a username to search..."/>
                                <datalist id="datalistOptions">
                                    <?php
                                        if($users != null) {
                                            foreach($users as $user) {
                                                $user = $this->core->array2obj($user);


                                    ?>

                                    <option value="<?php echo $user->username;?>">

                                    <?php 
                                            } 
                                        }
                                    ?>
                                </datalist>
                            </div>
                        </div>

                        <div class="form-group">
                            <label class="form-label">Title</label>
                            <input class="form-control" name="title" type="text" value="<?php echo set_value('title') ?>">
                        </div>


                        <div class="form-group">
                            <textarea class="form-control" name="message" placeholder="Write here..."><?php echo set_value('message'); ?></textarea>
                            <input type="hidden" value="admin" name="from_user">
                        </div>
                        <div class="form-group ml-auto">
                            <input type="submit" value="Send" class="btn btn-primary">
                        </div>
                    
                    </form>
                </div>
                    <!-- </div> -->
                <!-- </div> -->
            </div>
        </div>
    </div>
</div>