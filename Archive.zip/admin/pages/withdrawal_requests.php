<?php
defined("BASEPATH") or die("ACCESS DENIED");


$filter = isset($_GET["filter"]) ? $_GET["filter"] : "all";
$type = "withdrawals";

$requests = $this->ai->get_transactions($type, $filter, null);

?>

<div class="my-3 my-md-5">
  <div class="container">
    <div class="page-header">
      <h1 class="page-title">
        Withdrawal Requests
      </h1>
      
    </div>

    <div class="card">
      <div class="card-header">
          <?php echo ucwords($filter) ?> Requests
          
          <div class="ml-auto">
              Filter: 
              <ul class="list-group" style="display: inline-block;">
                  <li class="list-group-item" style="display: inline;"><a href="<?php echo base_url('vault/withdrawals/?filter=all');?>">All</a></li>
                  <li class="list-group-item" style="display: inline;"><a href="<?php echo base_url('vault/withdrawals/?filter=confirmed');?>">Confirmed</a></li>
                  <li class="list-group-item" style="display: inline;"><a href="<?php echo base_url('vault/withdrawals/?filter=pending');?>">Pending</a></li>
              </ul>
          </div>
      </div>
      
      <table class="table table-responsive card-table">
        <tbody>
          <tr>
            <th></th>
            <th>Username</th>
            <th>Amount</th>
            <th>Date</th>
            <th>Status</th>
            <th>Actions</th>
            
          </tr>
          
  
          
          <?php
            if(!empty($requests)){
              $count = 1;
              foreach($requests as $row){
                $current = $user->get_user($row->user);
          ?>
          <tr>
            <th><?php echo $count; ?></th>
            <th><?php echo $current->username; ?></th>  
            <th><?php echo number_format($row->amount, 2)?></th>
            <th><?php echo date("j-F-Y", $row->date); ?></th>
            <th><?php echo $row->status == 1 ? '<span class="status-icon bg-success"></span>Confirmed' : '<span class="status-icon bg-danger"></span>Unconfirmed' ?></th>
            <th>
                <?php 
                    if($row->status == 0) { 
                ?>
                <a class="btn btn-small btn-primary action" data-trans="<?php echo $row->id ?>" data-user="<?php echo $row->user; ?>" href="<?php echo base_url('admin/make_payment/?user=').$current->id?>">Payout</a>
                <?php } ?>
            </th>

          </tr>
          <?php
            $count++;
              }
            } else {
          ?>

            <tr>
              <th col="8">No transactions yet</th>
            </tr>
          <?php
            }
          ?>
        </tbody>
      </table>
    </div>
  </div>
</div>

<script>
    $(function() {
        $(".action").click(function(e) {
            e.preventDefault();
            const trans = $(this).data("trans");
            const url = "https://www.goldentradefund.com/vault/withdrawals/?action=confirm&id="+trans;
            window.location.href = url;
        })
    })
</script>





