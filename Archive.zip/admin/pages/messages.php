<?php
defined("BASEPATH") or die("ACCESS DENIED");
use Carbon\Carbon;
?>


<div class="my-3 my-md-5">
    <div class="container">
        <div class="page-header d-print-name">
            <div class="row align-items-center">
                <div class="col">
                    <h1 class="page-title">
                        Messages
                    </h1>
                </div>
                
                <div class="col-auto ms-auto d-print-none">
                    <div class="d-flex">
                    <a href="<?php echo base_url('vault/new-message') ?>" class="btn btn-primary">
                        New Message
                    </a>
                    </div>
                </div>
            </div>
        </div>

        <div class="card">
            <div class="table-responsive">
            <table class="table table-vcenter">
                <thead>
                    <tr>
                        <th>Name</th>
                        <th>Title</th>
                        <th>Last Reply</th>
                        <th>View Messages</th>
                    </tr>
                </thead>
                <tbody>
                    <?php                      
                        if($tickets != null) {
                            $first_done = false;
                            foreach($tickets as $index => $ticket) { 
                                $ticket = $this->core->array2obj($ticket);

                                $replies = $this->core->get_replies($ticket->id);
                                if($replies != null) {
                                    $last = $this->core->array2obj(array_values(array_slice($replies, -1))[0]);
                                    $message_time = Carbon::parse($last->created_at);
                                } else {
                                    $last = $ticket;
                                    $message_time = Carbon::parse($ticket->created_at);
                                }
                                $timeago = $message_time->diffForHumans(['options' => 0]);

                    ?>
                    <tr>
                        <td><?php echo ucwords( ($ticket->from_user == "admin") ? $ticket->to_user : $ticket->from_user ); ?></td>
                        <td class="text-muted" >
                                <?php echo $ticket->title ?>
                        </td>
                            <td class="text-muted" ><?php echo $last->from_user. " - ".$timeago; ?> </td>
                        <td>
                        <a href="<?php echo base_url('vault/view-message?ticketId='.$ticket->id);?>">View</a>
                        </td>
                    </tr>

                    <?php

                            }
                        }
                    ?>
                </tbody>
            </table>
        </div>
    </div>
</div>


<!-- Main Content -->
<div class="main-content">
        <section class="section">
          <div class="section-header">
            <h1>Messages</h1>
            <div class="section-header-breadcrumb">
              <div class="breadcrumb-item active"><a href="#">Dashboard</a></div>
              <div class="breadcrumb-item">Messages</div>
            </div>
          </div>

          <div class="section-body">
            <h2 class="section-title">Customer Notification Center</h2>
            <p class="section-lead">
              All of your updates and support ticket resolutions in one place.
            </p>

            <?php
                if(isset($errors)) {
            ?>
            <div class="row">
                <div class="col-12">
                    <div class="alert alert-info">
                        <?php echo $errors; ?>
                    </div>
                </div>
            </div>


            <?php } ?>

            <div class="row">
                <div class="col-md-12">
                    <div class="card">
                        <div class="card-header">
                            <h4>Messages</h4>
                        </div>

                        <div class="card-body">
                            <a href="#" class="btn btn-primary btn-icon icon-left btn-lg btn-block mb-4 d-md-none" data-toggle-slide="#ticket-items">
                                <i class="fas fa-list"></i> All Tickets
                            </a>

                            <div class="row">
                                <div class="col-12 col-sm-12 col-md-4">
                                    <ul class="nav nav-pills flex-column tickets ticket-items" id="myTab4" role="tablist">
                                        <?php
                                            
                                            if($tickets != null) {
                                                $first_done = false;
                                                foreach($tickets as $index => $ticket) { 
                                                    $ticket = $this->core->array2obj($ticket);

                                                    $replies = $this->core->get_replies($ticket->id);
                                                    if($replies != null) {
                                                        $last = $this->core->array2obj(array_values(array_slice($replies, -1))[0]);
                                                        $message_time = Carbon::parse($last->created_at);
                                                    } else {
                                                        $message_time = Carbon::parse($ticket->created_at);
                                                    }
                                                    $timeago = $message_time->diffForHumans(['options' => 0]);

                                        ?>
                                        <li class="nav-item">
                                            <a class="nav-link ticket-item <?php echo ($first_done == false) ? 'active' : ''?>" id="home-tab4" data-toggle="tab" href="#home<?php echo $index; ?>" role="tab" aria-controls="home" aria-selected="true">
                                                <div class="ticket-title">
                                                    <h5><?php echo ucwords($ticket->title); ?></h5>
                                                </div>
                                                <div class="ticket-desc">
                                                    <div>Admin <span class="bullet"></span> <?php echo $timeago; ?></div>
                                                </div>
                                            </a>
                                        </li>

                                        <?php  
                                                    $first_done = true;
                                                }
                                            }

                                        ?>
                                    </ul>

                                </div>

                                <div class="col-12 col-sm-12 col-md-8">
                                    <div class="tab-content no-padding ticket-content" id="myTab2Content">
                                        <!-- Ticket content start -->
                                        <?php
                                            if($tickets != null) {
                                                $first_done = false;
                                                foreach($tickets as $index => $ticket) { 
                                                    $ticket = $this->core->array2obj($ticket);

                                                    $replies = $this->core->get_replies($ticket->id);
                                                    $timeago = Carbon::parse($ticket->created_at)->diffForHumans(["options" => 0]);


                                        ?>
                                        <div class="tab-pane fade show <?php echo ($first_done == false) ? 'active' : ''?>" id="home<?php echo $index; ?>" role="tabpanel" aria-labelledby="home-tab4">
                                            
                                            <div class="ticket-header">
                                                <div class="ticket-sender-picture img-shadow">
                                                    <img src="<?php echo base_url(); ?>assets/img/avatar/avatar-5.png" alt="image">
                                                </div>
                                                <div class="ticket-detail">
                                                    <div class="ticket-title">
                                                    <h4><?php echo ucwords($ticket->title) ?></h4>
                                                    </div>
                                                    <div class="ticket-info">
                                                        <div class="font-weight-600"> <span class="bullet"></span> <?php echo $timeago; ?></div>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="ticket-description" id="messageFor<?php echo $ticket->id; ?>">
                                                <p>
                                                    <?php echo $ticket->text; ?>
                                                </p>      
                                                <div class="ticket-divider"></div>                            
                                            </div>

                                            <!-- Replies start -->
                                            <?php 
                                                if($replies != NULL) {
                                                    foreach($replies as $reply) {
                                                    $reply = $this->core->array2obj($reply);

                                            ?>

                                            <div class="ticket-header" id="replyHeadFor-<?php echo $ticket->id; ?>">
                                                <!-- <div class="ticket-sender-picture img-shadow">
                                                    <img src="<?php //echo base_url('theme/app/assets/img/avatar/avatar-2.png'); ?>" alt="image">
                                                </div> -->
                                                <div class="ticket-detail">
                                                    <div class="ticket-title">
                                                    <h4><?php echo ucwords($reply->title) ?></h4>
                                                    </div>
                                                    <div class="ticket-info">
                                                    <div class="font-weight-600"><?php echo $reply->from_user ?></div>
                                                    <div class="bullet"></div>
                                                    <div class="text-primary font-weight-600"><?php echo Carbon::now()->diffForHumans(Carbon::parse($reply->created_at), ['options' => 0]); ?></div>
                                                    </div>
                                                </div>
                                            </div>

                                            <div class="ticket-description" id="replyFor-<?php echo $ticket->id; ?>">
                                                <p>
                                                    <?php echo $reply->text; ?>
                                                </p>  
                                                <div class="ticket-divider"></div>                                
                                            </div>

                                            <?php
                                                    }
                                                }
                                            ?>
                                            <!-- Replies end -->

                                            <div class="ticket-form">
                                                <form action="<?php echo base_url('app/messages') ?>" method="POST">
                                                    <div class="form-group">
                                                        <input type="hidden" name="title" value="Re: <?php echo $ticket->title ?>">
                                                        <input type="hidden" value="<?php echo $user->username ?>" name="from_user">
                                                        <input type="hidden" value="admin" name="to_user">
                                                        <input type="hidden" value="<?php echo $ticket->id; ?>" name="replying_to">
                                                        <textarea name="message" class="summernote form-control" placeholder="Type a reply ..."></textarea>
                                                    </div>
                                                    <div class="form-group text-right">
                                                        <button class="btn btn-primary btn-lg reply">
                                                        Reply
                                                        </button>
                                                    </div>
                                                </form>
                                            </div>
                                        </div>

                                        <?php
                                                    $first_done = true;
                                                }
                                            }
                                        ?>
                                        <!-- Ticket content end -->
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
          </div>
        </section>
    </div>


    <script>
    $(function() {
        // $(".reply").click(function(e) {
        //     e.preventDefault();
        //     alert("will submit")
        // })

        // $(".ticket-item").click(function(e) {
        //     e.preventDefault();
        //     $(".ticket-item").removeClass('active')
        //     $(this).addClass('active');
        //     const ticket_id = $(this).data('message');

        //     $(".ticket-header").hide(100);
        //     $(".ticket-description").hide(100);

        //     $("#headerFor-" + ticket_id).show(100);
        //     $("#replyHeadFor-" + ticket_id).show(100);
        //     $("#replyFor-" + ticket_id).show(100);
        //     $("#messageFor-" + ticket_id).show(100);
        //     // $("#message-"+ticket_id).show(); //show main content for this message
        //     // $("#replyFor-"+ticket_id).show(); // show replies to the message
    
        //     // const next = $('[data-message="' + ticket_id + '"]')
        //     // next.addClass("active")
            
        // })
        // alert("will load")
    })
    </script>