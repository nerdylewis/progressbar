<?php
defined("BASEPATH") or die("ACCESS DENIED");
$user_details = $this->user->get_user($user_id);
?>
<div class="my-3 my-md-5">
  <div class="container">
    <div class="row">
      <div class="col-lg-4">
                <div class="card">
                  <div class="card-header">
                    <h3 class="card-title">Modify Balance</h3>
                  </div>
                  <div class="card-body">
                    <form method="post" action="#">
                      <div class="row">
                        <?php if(isset($error)) { ?>
                          <div class="col-xl-12 col-lg-12">
                            <div class="alert alert-<?php echo $error->status; ?>">
                              <?php echo $error->message; ?>
                            </div>
                          </div>
                        
                        <?php } ?>
                      </div>
                      
                      <div class="form-group">
                        <label class="form-label">Old Profits</label>
                        <input name="oldpass" class="form-control" placeholder="Enter your current password" value="<?php echo number_format($user_details->balance, 2)?>" readonly>
                      </div>

                      <div class="form-group">
                        <label class="form-label">New Profits</label>
                        <input name="new_bal" type="text" class="form-control" value="" placeholder="New account balance" required>
                      </div>

                      <div class="form-group">
                        <label class="form-label">Old Startup Capital</label>
                        <input name="oldpass" class="form-control" placeholder="Enter your current password" value="<?php echo number_format($user_details->trading_balance, 2)?>" readonly>
                      </div>

                      <div class="form-group">
                        <label class="form-label">New Startup Capital</label>
                        <input name="new_start" type="text" class="form-control" value="" placeholder="New account balance" required>
                      </div>

                      <div class="form-footer">
                        <button type="submit" class="btn btn-primary btn-block">Save</button>
                      </div>                 
                    </form>
                  </div>
                </div>
              </div>
    </div>
  </div>
</div>

<script>
$(function() {
  $('form').submit(function(e){
    e.preventDefault();
    var portfolio_balance = $('input[name="new_bal"]').val()
    var startup_balance = $('input[name="new_start"]').val()
    var submit = $('button[type="submit"]')
    submit.attr('disabled', true)
    $.ajax({
      url: "<?php echo base_url('admin/modify_balance');?>",
      type: "POST",
      dataType: "JSON",
      cache: false,
      data: {"user" : "<?php echo $user_details->id?>", "balance" : portfolio_balance, "trading_balance" : startup_balance},
      success: function(resp) {
        if(resp.error == "ok"){
          alert("updated successfully");
          window.location.reload();
        }else {
          alert(resp.error)
          submit.attr('disabled', false)
        }
      },
      error: function(xhr, status, error) {
        alert(error)
        submit.attr('disabled', false)
      }
    })
  })
})
</script>