<?php
defined("BASEPATH") or die("ACCCESS DENIED");
$settings = $user->get_settings();
?>
<div class="my-3 my-md-5">
  <div class="container">
    <div class="row">


    <div class="card">
                  <div class="card-header">
                    <h3 class="card-title">Edit Settings</h3>
                  </div>
                  <div class="card-body">
                    <form method="post" action="<?php echo base_url('admin/settings');?>">
                      <div class="row">
                        <?php if(isset($error)) { ?>
                          <div class="col-xl-12 col-lg-12">
                            <div class="alert alert-<?php echo $error->status; ?>">
                              <?php echo $error->message; ?>
                            </div>
                          </div>
                        
                        <?php } ?>
                      </div>
                      <div class="form-group">
                        <label class="form-label">Number of days before cashout</label>
                        <input name="days" class="form-control" placeholder="new wallet" value="<?php echo $settings->days?>">
                      </div>

                      <div class="form-group">
                        <label class="form-label">Your Wallet Address</label>
                        <input name="address" class="form-control" placeholder="new wallet" value="<?php echo $settings->address?>">
                      </div>
                      <div class="form-group">
                        <label class="form-label">Minimum amount</label>
                        <input type="text" name="min_amount" class="form-control" value="<?php echo $settings->min_amount;?>">
                      </div>

                      <div class="form-group">
                        <label class="form-label">Maximum amount</label>
                        <input type="text" name="max_amount" class="form-control" value="<?php echo $settings->max_amount;?>">
                      </div>
                      <div class="form-footer">
                        <button class="btn btn-primary btn-block">Save</button>
                      </div>

                      
                    </form>
                  </div>
                </div>


    </div>
  </div>
</div>