<?php
defined("BASEPATH") or die("ACCESS DENIED");
// $plans = 
?>
<div class="my-3 my-md-5">
  <div class="container">
    <div class="page-header">
      <h1 class="page-title">
        All Investment Plans
      </h1>
      <button class="btn btn-small btn-primary ml-auto">Add Plan</button>
    </div>

    <div class="col-12">
      <div class="card">
        <div class="card-header">
          <h3 class="card-title">Invoices</h3>
        </div>

        <div class="table-responsive">
          <table class="table card-table table-vcenter text-nowrap">
            <thead>
              <tr>
                <!-- <th class="w-1">No.</th> -->
                <th>Name</th>
                <th>Return on Investment (%)</th>
                <th>Minimum Investment</th>
                <th>Maximum Investment</th>
                <th>Actions <i class="fe fe-settings"></i></th>
              </tr>
            </thead>
            <tbody>
              <?php
                foreach($plans as $plan) {
              ?>

              <tr>
                  <td><?php echo $plan->name; ?></td>
                  <td><?php echo $plan->roi ?> %</td>
                  <td><?php echo $plan->min_amount ?> BTC</td>
                  <td><?php echo $plan->max_amount ?> BTC</td>
                  <td><a class="btn btn-small btn-danger" href="<?php echo base_url('vault/plans?action=delete&id='.$plan->id) ?>">Delete</a> | <a class="btn btn-small btn-primary" href="<?php echo base_url() ?>">Edit</a></td>
              
              </tr>
              <?php } ?>
              <!-- <tr>
                <td><span class="text-muted">001401</span></td>
                <td><a href="invoice.html" class="text-inherit">Design Works</a></td>
                <td>
                  Carlson Limited
                </td>
                <td>
                  87956621
                </td>
                <td>
                  15 Dec 2017
                </td>
                <td>
                  <span class="status-icon bg-success"></span> Paid
                </td>
                <td>$887</td>
                <td class="text-right">
                  <a href="javascript:void(0)" class="btn btn-secondary btn-sm">Manage</a>
                  <div class="dropdown">
                    <button class="btn btn-secondary btn-sm dropdown-toggle" data-toggle="dropdown">Actions</button>
                  </div>
                </td>
                <td>
                  <a class="icon" href="javascript:void(0)">
                    <i class="fe fe-edit"></i>
                  </a>
                </td>
              </tr> -->
            </tbody>
          </table>
        </div>
      </div>
    </div>
  </div>
</div>


                  
                  </div>
                </div>
              </div>