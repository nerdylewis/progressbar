<?php
defined("BASEPATH") or die("ACCESS DENIED");
use Carbon\Carbon;
?>


<div class="my-3 my-md-5">
    <div class="container">
        <div class="page-header d-print-name">
            <div class="row align-items-center">
                <div class="col">
                    <h1 class="page-title">
                        Read Message
                    </h1>
                </div>
            </div>
        </div>

        <div class="card">
            <div class="card-body">
                <?php
                    if($messages != null) {
                        $ticket = $this->core->array2obj($messages[0]);
                        foreach($messages as $value) {
                            $message = $this->core->array2obj($value);
                            // $message = $value;
                            // var_dump($message);
                            // die;

                ?>
                <div>
                    <div class="d-flex align-items-center pt-4 mb-2">
                        <span class="avatar" style="background-image: url(../static/avatars/001f.jpg)"></span>
                        <div class="ms-3">
                            <a href="#" class="ml-4 text-body"><?php echo $message->from_user; ?></a>
                            <div class="text-muted ml-4"><?php echo Carbon::parse($message->created_at)->diffForHumans(['options' => 0]); ?></div>
                        </div>
                        
                    </div>

                    <h3 class="card-title"><a href="javascript:void(0)"><?php echo ucwords($message->title); ?></a></h3>
                    <div class="text-muted"><?php echo $message->text ?></div>
                
                </div>
                <?php
                        }
                ?>
                <div class="mb-3 mt-5">
                    <label class="form-label">Send a Reply</label>
                    <form method="POST" action="">
                        <div class="form-group">
                            <textarea class="form-control" name="message" placeholder="Write here..."></textarea>
                            <input type="hidden" name="title" value="Re: <?php echo $ticket->title ?>">
                            <input type="hidden" value="admin" name="from_user">
                            <input type="hidden" value="<?php echo $customer->username ?>" name="to_user">
                            <input type="hidden" value="<?php echo $ticket->id; ?>" name="replying_to">
                        </div>
                        <div class="form-group ml-auto">
                            <input type="submit" value="Send" class="btn btn-primary">
  
                        </div>

                    </form>
                </div>
                <?php } ?>
            
            </div>

        </div>
    </div>
</div>