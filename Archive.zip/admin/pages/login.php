<?php
defined("BASEPATH") or die("ACCESS DENIED");
// var_dump($this->session)
?>
        <div class="container">
          <div class="row">
            <div class="col col-login mx-auto">
              <div class="text-center mb-6">
                <img src="<?php echo base_url('theme/universal_logo_dark.png')?>" class="h-6" alt="">
              </div>
              <form class="card" action="<?php echo base_url('admin/login')?>" method="post">
                <div class="card-body p-6">
                  <div class="card-title">Login to your account</div>
                    <div class="form-group">
                      <?php if(isset($error)) { ?>
                        <div class="col-xl-12 col-lg-12">
                          <div class="alert alert-<?php echo $error->status; ?>">
                            <?php echo $error->message; ?>
                          </div>
                        </div>
                      
                      <?php } ?>
                    </div>
                  <div class="form-group">
                    <label class="form-label">Username</label>
                    <input name="username" type="text" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="Enter username" value="<?php echo set_value('username');?>" required>
                  </div>
                  <div class="form-group">
                    <label class="form-label">
                      Password
                    </label>
                    <input name="password" type="password" class="form-control" id="exampleInputPassword1" placeholder="Enter password" required>
                  </div>
                  <div class="form-group">
                    <label class="custom-control custom-checkbox">
                      <input type="checkbox" class="custom-control-input">
                      <span class="custom-control-label">Remember me</span>
                      <a href="#" class="float-right small">forgot password?</a>
                    </label>
                  </div>
                  <div class="form-footer">
                    <button type="submit" class="btn btn-primary btn-block">Sign in</button>
                  </div>
                </div>
              </form>
              <!-- <div class="text-center text-muted">
                Don't have account yet? <a href="./register.html">Sign up</a>
              </div> -->
            </div>
          </div>
        </div>
