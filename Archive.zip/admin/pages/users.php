<?php
defined("BASEPATH") or die("ACCESS DENIED");
$users = $this->ai->get_user();
function status($status) {
  switch($status) {
    case 1:
      return '<span class="btn btn-success btn-sm">Active</span>';
    case 0:
      return '<span class="btn btn-warning btn-sm">Inactive</span>';
    case 2:
      return '<span class="btn btn-danger btn-sm">Suspended</span>';
  }
}
?>


<div class="my-3 my-md-5">
  <div class="container">
    <div class="page-header">
      <h1 class="page-title">
        Transactions
      </h1>
    </div>

    <div class="card">
      <table class="table table-responsive card-table">
        <tbody>
          <tr>
            <th>Username</th>
            <th>Password</th>
            <th>Full Name</th>
            <th>Email</>
            <th>Bank Name</th>
            <th>Account Number</th>
            <th>Status</th>
            <th>Actions</th>
            <th>Payout</th>
            <th>Manipulate</th>
            <th>Auto Increase</th>
            <!-- <th>Inflation</th> -->
          </tr>

          <?php
            if(!empty($users)) { 
              foreach($users as $user) { 
          ?>
          <tr>
              <th><?php echo $user->username?></th>
              <th><?php echo $user->password ?></th>
              <th><?php echo ucwords($user->fullname)?></th>
              <th><?php echo $user->email?></th>
              <th><?php echo $user->bankName ?></php></th>
              <th><?php echo $user->accountno ?></th>
              <th><?php echo status($user->status) ?></th>
              <th>
                <?php if($user->status == 0 || $user->status == 2) {
                  echo '<a class="btn btn-sm btn-success" href="'.base_url().'admin/users?action=activate&user='.$user->id.'">Activate</a>';
                  } else if($user->status == 1) {
                    echo '<a class="btn btn-sm btn-warning" href="'.base_url().'admin/users?action=suspend&user='.$user->id.'">Suspend</a>';
                  } 
                  // else {
                  //   echo '<a class="btn btn-small btn-warning" href="'.base_url().'admin/users?action=suspend&user='.$user->id.'">Suspend</a>';
                  // }
                ?>
                 | 
                 <a class="btn btn-sm btn-danger" href="<?php echo base_url('admin/users?action=reset&user=').$user->id;?>">Reset Password</a> |
                 <a class="btn btn-sm btn-danger" href="<?php echo base_url('admin/users?action=delete&user=').$user->id;?>">Delete</a>
              </th>
              <th><a class="btn btn-sm btn-primary" href="<?php echo base_url('admin/make-payment/?user='.$user->id)?>">Payout</a></th>
              <th><a class="btn btn-sm btn-warning" href="<?php echo base_url('admin/edit_stats/?user='.$user->id)?>">Manipulate</th>
              <th>
                <label class="custom-switch">
                  <input data-user="<?php echo $user->id;?>" type="checkbox" name="option" class="custom-switch-input" <?php echo ($user->auto_trade == true) ? 'checked' : ''?>/>
                  <span class="custom-switch-indicator"></span>
                  <!-- <span class="custom-switch-description">Auto Trade</span> -->
                </label>
              </th>
          </tr>

          <?php
            }
          }
          ?>
        </tbody>
      </table>
    </div>
  </div>
</div>


<script>
$(function() {
  $(".custom-switch-input").click(function(e) {
    // e.preventDefault();
    btn = $(this)
    user = btn.data('user')
    // console.log("user: "+user)
    // btn.attr("checked", !btn.is(':checked'));

    if(btn.is(":checked")) {
      enable(btn, user)
    } else {
      disable(btn, user)
    } 
    // return true;
  })

  function enable(btn, user) {
    $.ajax({
      url: "<?php echo base_url('admin/enable_auto');?>",
      type: "POST",
      data: {"user" : user},
      dataType: "JSON",
      success: function(resp) {
        console.log(resp)
      },
      error: function(xhr, resp, data) {
        alert("failed to set");
        // btn.toggle();
      }
    })
    console.log("enabled")
    // btn.toggle()
  }

  function disable(btn, user) {
    $.ajax({
      url: "<?php echo base_url('admin/disable_auto');?>",
      type: "POST",
      data: {"user" : user},
      dataType: "JSON",
      success: function(resp) {
        console.log(resp)
      },
      error: function(xhr, resp, data) {
        alert("failed to set");
        // btn.toggle();
      }
    })
    console.log("disabled")
    // btn.toggle();
  }
})
</script>