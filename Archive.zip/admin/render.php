<?php
defined("BASEPATH") or die("ACCESS DENIED");
?>
<html>
  <head>
    <meta charset="UTF-8">
	  <meta name="viewport" content="width=device-width">
    <title> <?php echo $site_settings->site_name." - ". $title; ?> </title>
    <link rel="stylesheet" href="<?php echo base_url('theme/admin/admin.css')?>">
    <link rel="stylesheet" href="https://pro.fontawesome.com/releases/v5.10.0/css/duotone.css" integrity="sha384-R3QzTxyukP03CMqKFe0ssp5wUvBPEyy9ZspCB+Y01fEjhMwcXixTyeot+S40+AjZ" crossorigin="anonymous"/>
<link rel="stylesheet" href="https://pro.fontawesome.com/releases/v5.10.0/css/fontawesome.css" integrity="sha384-eHoocPgXsiuZh+Yy6+7DsKAerLXyJmu2Hadh4QYyt+8v86geixVYwFqUvMU8X90l" crossorigin="anonymous"/>
    <link rel="stylesheet" href="https://pro.fontawesome.com/releases/v5.10.0/css/all.css" integrity="sha384-AYmEC3Yw5cVb3ZcuHtOA93w35dYTsvhLPVnYs9eStHfGJvOvKxVfELGroGkvsg+p" crossorigin="anonymous"/>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/2.1.3/jquery.min.js"></script>

    
  </head>
  <body id="page-top">
    <style>
.clickable{
  cursor: pointer;
}
</style>
    <!-- preloader begin-->
    <div class="preloader" style="display: none;">
        <div class="loader">
            <hr><hr>
        </div>
    </div>
    <!-- preloader end -->
    <div class="page">
      <div class="<?php echo ($this->auth->is_authenticated("user") == TRUE) ? 'page-main' : 'page-single'?>">
        <?php if($this->auth->is_authenticated("user") == TRUE) { ?>
        <div class="header py-4">
          <div class="container">
            <div class="d-flex">
              <a class="header-brand" href="<?php echo base_url('vault/dashboard');?>">
                  <img src="<?php echo base_url('theme/universal_logo_dark.png');?>" class="header-brand-img" alt="tabler logo">
              </a>

              
              <div class="d-flex order-lg-2 ml-auto">
                <div class="dropdown">
                  <a href="#" class="nav-link pr-0 leading-none" data-toggle="dropdown">
                    <span class="avatar" style="background-color: gray;"></span>
                    <span class="ml-2 d-none d-lg-block">
                    <span class="text-default"><?php echo $data->user->username;?></span>
                      <small class="text-muted d-block mt-1">Investor</small>
                    </span>
                  </a>
                    
                  <div class="dropdown-menu dropdown-menu-right dropdown-menu-arrow">
                    <a class="dropdown-item" href='<?php echo base_url("app/profile")?>'>
                      <i class="dropdown-icon fa fas-user"></i> Profile Settings
                    </a>
                    <a class="dropdown-item" href='<?php echo base_url("app/logout")?>'>
                      <i class="dropdown-icon fa fas-log-out"></i> Sign out
                    </a>
                  </div>     
                </div>
              </div>

              <a href="#" class="header-toggler d-lg-none ml-3 ml-lg-0" data-toggle="collapse" data-target="#headerMenuCollapse">
                  <span class="header-toggler-icon"></span>
              </a>
            </div>

            
          </div>
        </div>
        <div class="header d-lg-flex p-0 collapse" id="headerMenuCollapse" style="">
          <div class="container">
            <div class="row align-items-center">
              <div class="col-lg order-lg-first">
                <ul class="nav nav-tabs border-0 flex-column flex-lg-row">
                            
                            <li class="nav-item">
                                <a href="<?php echo base_url('vault/dashboard');?>" class="nav-link <?php echo $page == 'dashboard' ? 'active' : ''?>"><i class="fa fa-home"></i> Dashboard</a>
                            </li>
                            <li class="nav-item">
                                <a href="<?php echo base_url('vault/withdrawals')?>" class="nav-link <?php echo $page == 'withdrawals' ? 'active' : ''?>"><i class="fa fa-box"></i> Withdrawals</a>
                            </li>
                            <li class="nav-item">
                                <a href="<?php echo base_url('vault/deposits') ?>" class="nav-link <?php echo $page == 'deposits' ? 'active' : '' ?>">
                                    <i class="fa fa-download"></i> Deposits
                                </a>
                            </li>
                            <li class="nav-item">
                                <a href="<?php echo base_url('vault/users');?>" class="nav-link <?php echo $page == 'users' ? 'active' : ''?>"><i class="fa fa-user"></i> Users</a>
                                
                            </li>
                            <li class="nav-item">
                                <a href="<?php echo base_url('vault/plans');?>" class="nav-link <?php echo $page == 'plans' ? 'active' : ''?>"><i class="fa fa-calendar"></i> Investment Plans</a>
                            </li>
                            <li class="nav-item">
                                <a href="<?php echo base_url('vault/settings');?>" class="nav-link <?php echo $page == 'settings' ? 'active' : ''?>"><i class="fa fa-cog"></i> Settings</a>
                                
                            </li>

                            <li class="nav-item">
                            <a href="<?php echo base_url('vault/messages');?>" class="nav-link <?php echo $page == 'messages' ? 'active' : ''?>"><i class="fa fa-envelope"></i> Messages</a>
                            </li>
                        </ul>
              </div>
            </div>
          </div>
        </div>
        <?php } ?>
        <?php $this->load->view("admin/pages/$page"); ?>

      </div>

      <footer class="footer">
        <div class="container">
          <div class="row align-items-center flex-row-reverse">
              
            <div class="col-12 col-lg-auto mt-3 mt-lg-0 text-center">
              Copyright &copy; <?php echo date("Y").". ".$site_settings->site_name; ?> . All rights reserved.
            </div>
          </div>
        </div>
      </footer>
    </div>
    <!--Start of Tawk.to Script-->
    <!-- <script type="text/javascript">
    var Tawk_API=Tawk_API||{}, Tawk_LoadStart=new Date();
    (function(){
    var s1=document.createElement("script"),s0=document.getElementsByTagName("script")[0];
    s1.async=true;
    s1.src='https://embed.tawk.to/5ecac2b88ee2956d73a41ef9/default';
    s1.charset='UTF-8';
    s1.setAttribute('crossorigin','*');
    s0.parentNode.insertBefore(s1,s0);
    })();
    </script> -->
    <!--End of Tawk.to Script-->
    
    <script type="text/javascript" src="<?php echo base_url('theme/admin/assets/js/vendors/bootstrap.bundle.min.js');?>"></script>
    <script type="text/javascript" src="<?php echo base_url('theme/admin/assets/js/vendors/jquery.sparkline.min.js');?>"></script>
    <script type="text/javascript" src="<?php echo base_url('theme/admin/assets/js/vendors/selectize.min.js');?>"></script>
    <script type="text/javascript" src="<?php echo base_url('theme/admin/assets/js/vendors/jquery.tablesorter.min.js');?>"></script>
    <script type="text/javascript" src="<?php echo base_url('theme/admin/assets/js/vendors/jquery-jvectormap-2.0.3.min.js');?>"></script>
  </body>
</html>